import os

from crewai import LLM


# =================================================
# Grok (xAI) API Key
# =================================================

XAI_API_KEY = os.getenv("XAI_API_KEY")

if not XAI_API_KEY:
    raise ValueError(
        "XAI_API_KEY is not configured. "
        "Add XAI_API_KEY to your .env file or to Streamlit Cloud Secrets."
    )


# =================================================
# Grok LLM
# =================================================

# Change the model without touching code: set XAI_MODEL in .env / secrets.
# See https://docs.x.ai for the current model list.
XAI_MODEL = os.getenv("XAI_MODEL", "grok-4.7")

llm = LLM(
    model=f"xai/{XAI_MODEL}",
    api_key=XAI_API_KEY,
    temperature=0
)
