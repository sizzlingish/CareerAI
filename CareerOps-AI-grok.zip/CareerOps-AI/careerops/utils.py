from pypdf import PdfReader


def extract_cv_text(uploaded_file):
    """Return plain text from an uploaded PDF or TXT CV."""

    if uploaded_file.type == "application/pdf":

        pdf_reader = PdfReader(uploaded_file)

        text = ""

        for page in pdf_reader.pages:
            page_text = page.extract_text()

            if page_text:
                text += page_text + "\n"

        return text

    elif uploaded_file.type == "text/plain":

        return uploaded_file.read().decode("utf-8")

    return ""
